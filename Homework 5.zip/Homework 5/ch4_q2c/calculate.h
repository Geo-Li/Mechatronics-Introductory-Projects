#ifndef calculate__H__
#define calculate__H__

#include "io.h"

void calculateGrowth(Investment *invp);

#endif
