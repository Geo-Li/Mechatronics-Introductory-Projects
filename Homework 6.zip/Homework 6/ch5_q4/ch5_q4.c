
int main(void) {
    unsigned int u1=33, u2=17, u3;
    u3 = u1 & u2; // bitwise AND
    u3 = u1 | u2; // bitwise OR
    u3 = u2 << 4; // shift left 4 spaces, or multiply by 2ˆ4 = 16
    u3 = u1 >> 3; // shift right 3 spaces, or divide by 2ˆ3 = 8
    return 0;
}
